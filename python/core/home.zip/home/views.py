#Django templet tags

from django.shortcuts import render
 
from django.http import HttpResponse
# Create your views here.

def home(request):
    peoples = [
        {'name': 'Rajesh', 'age':25},
        {'name': 'Lucky', 'age':26},
        {'name': 'Kamala', 'age':22},
        {'name': 'Kalyani', 'age':21},
        {'name': 'kavya', 'age':10}

    ]
    for people in peoples:
        if people['age']:
            print("Yes")

    vegetables = ['Pumpkin', 'Tomato', 'Potatoe']

#     text = """       
#       Lorem ipsum dlor sit amet consectetur, adipisicing elit. Incident sequi consectetur quas, Provident quo eli
# """
    # for people in peoples:
    #     print(people)
    return render(request, "home/index.html", context = {'page' : 'Django 2023 project', 'peoples': peoples, 'vegetables': 'vegetables'})
    # return HttpResponse("""<h1>Hey I am a Django Server.</h1>
    #                     <p>Hey this is coming from Django server</p>
    #                     <hr>
    #                     <h3 style="color:red">Hope you are loving it :)

    #                     """)

def about(request):
    contact = {'page':'About'}
    return render(request, "home/about.html", contact)

 
def contact(request):
    contact = {'page':'Contact'}
    return render(request, "home/contact.html", contact)



def success_page(request):
    print("*" * 10)
    contact = {'page':'Contact'}
    return HttpResponse("<h1>Hey this is a Success page</h1>")


